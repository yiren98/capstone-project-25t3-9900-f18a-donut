import sqlite3
import csv

def export_to_csv():
    """导出数据到 CSV 文件"""
    conn = sqlite3.connect('reddit_data.db')
    cursor = conn.cursor()
    
    # 导出帖子数据
    cursor.execute("SELECT * FROM submissions")
    submissions = cursor.fetchall()
    
    with open('submissions.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['ID', 'Reddit_ID','标题', '作者', '讨论链接', 'URL', '分数', '评论数', 
                        '创建时间戳', '内容', '时区', '地点', '爬取时间', '创建时间'])
        writer.writerows(submissions)
    
    print(f"✅ 已导出 {len(submissions)} 条帖子数据到 submissions.csv")
    
    # 导出用户数据
    cursor.execute("SELECT * FROM users")
    users = cursor.fetchall()
    
    with open('users.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['ID', '用户名', '评论Karma', '链接Karma', '用户创建时间', '用户时区'])
        writer.writerows(users)
    
    print(f"✅ 已导出 {len(users)} 条用户数据到 users.csv")
    
    conn.close()

if __name__ == "__main__":
    export_to_csv()
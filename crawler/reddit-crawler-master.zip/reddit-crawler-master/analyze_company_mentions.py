import pandas as pd
import re
from collections import Counter
import os

def analyze_company_mentions():
    """分析CSV文件中的公司提及情况"""
    print("正在分析你的CSV文件...")
    
    # 检查文件是否存在
    if not os.path.exists('submissions.csv'):
        print("❌ submissions.csv 文件不存在，请先运行爬虫和导出")
        return
    
    # 读取CSV文件
    try:
        df = pd.read_csv('submissions.csv')
    except Exception as e:
        print(f"❌ 读取CSV文件失败: {e}")
        return
    
    print(f"数据集总帖子数: {len(df)}")
    print("=" * 60)
    
    # 定义要分析的公司列表
    companies = [
        'Google', 'Microsoft', 'Apple', 'Amazon', 'Facebook', 'Meta',
        'OpenAI', 'Tesla', 'NVIDIA', 'Intel', 'AMD', 'IBM', 'Oracle',
        'Salesforce', 'Adobe', 'Spotify', 'Netflix', 'Twitter', 'X',
        'Reddit', 'GitHub', 'GitLab', 'Docker', 'MongoDB', 'Redis',
        'PostgreSQL', 'MySQL', 'SQLite', 'Apache', 'Linux'
    ]
    
    # 准备分析结果
    company_mentions = []
    
    # 确保内容列是字符串类型
    df['内容'] = df['内容'].astype(str)
    
    for company in companies:
        # 使用正则表达式匹配单词边界，避免部分匹配
        pattern = r'\b' + re.escape(company) + r'\b'
        
        # 在标题和内容中搜索
        title_matches = df['标题'].str.contains(pattern, case=False, na=False).sum()
        content_matches = df['内容'].str.contains(pattern, case=False, na=False).sum()
        
        total_matches = title_matches + content_matches
        
        if total_matches > 0:
            # 找到包含该公司提及的帖子示例
            company_posts = df[
                df['标题'].str.contains(pattern, case=False, na=False) | 
                df['内容'].str.contains(pattern, case=False, na=False)
            ]
            
            # 获取第一个帖子的内容预览
            if len(company_posts) > 0:
                first_post = company_posts.iloc[0]
                content = str(first_post['内容'])  # 确保是字符串
                content_preview = content[:200] + '...' if len(content) > 200 else content
                
                company_mentions.append({
                    '公司': company,
                    '提及次数': total_matches,
                    '标题提及': title_matches,
                    '内容提及': content_matches,
                    '示例帖子': first_post['标题'][:100] + '...' if len(first_post['标题']) > 100 else first_post['标题'],
                    '内容预览': content_preview,
                    '作者': first_post['作者'],
                    '分数': first_post['分数']
                })
    
    # 按提及次数排序
    company_mentions.sort(key=lambda x: x['提及次数'], reverse=True)
    
    # 输出结果
    if company_mentions:
        print("🏢 公司提及分析结果:")
        print("=" * 60)
        
        for i, company in enumerate(company_mentions[:20], 1):  # 只显示前20个
            print(f"{i}. {company['公司']}:")
            print(f"   📊 总提及: {company['提及次数']} 次")
            print(f"   📝 标题提及: {company['标题提及']} 次")
            print(f"   📄 内容提及: {company['内容提及']} 次")
            print(f"   👤 作者: {company['作者']}")
            print(f"   ⭐ 分数: {company['分数']}")
            print(f"   📋 示例: {company['示例帖子']}")
            print(f"   🔍 内容预览: {company['内容预览']}")
            print("-" * 50)
        
        # 统计信息
        total_mentions = sum([c['提及次数'] for c in company_mentions])
        print(f"\n📈 统计摘要:")
        print(f"   总提及次数: {total_mentions}")
        print(f"   涉及公司数: {len(company_mentions)}")
        print(f"   平均每家公司提及: {total_mentions/len(company_mentions):.1f} 次")
        
        # 最常提及的公司
        top_companies = [c['公司'] for c in company_mentions[:5]]
        print(f"   🏆 最常提及的前5公司: {', '.join(top_companies)}")
        
    else:
        print("❌ 没有找到任何公司提及")
    
    # 额外的技术相关分析
    print("\n🔧 技术相关分析:")
    print("=" * 60)
    
    tech_keywords = [
        'Python', 'JavaScript', 'Java', 'C++', 'C#', 'Go', 'Rust',
        'AI', 'Machine Learning', 'Deep Learning', 'Data Science',
        'Web Development', 'Mobile Development', 'Cloud', 'AWS',
        'Azure', 'Google Cloud', 'Docker', 'Kubernetes', 'API'
    ]
    
    tech_results = []
    for keyword in tech_keywords:
        pattern = r'\b' + re.escape(keyword) + r'\b'
        matches = df['标题'].str.contains(pattern, case=False, na=False).sum() + \
                 df['内容'].str.contains(pattern, case=False, na=False).sum()
        
        if matches > 0:
            tech_results.append((keyword, matches))
    
    tech_results.sort(key=lambda x: x[1], reverse=True)
    
    for keyword, count in tech_results[:10]:
        print(f"   {keyword}: {count} 次提及")

if __name__ == "__main__":
    analyze_company_mentions()
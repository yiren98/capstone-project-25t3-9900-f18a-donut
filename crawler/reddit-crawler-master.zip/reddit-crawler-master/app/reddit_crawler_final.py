import sys
import time
import random
import requests
import sqlite3
from datetime import datetime
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "https://www.reddit.com/"
usernames = set()

def init_database():
    """初始化数据库，使用阿拉伯数字ID"""
    conn = sqlite3.connect('reddit_data.db')
    cursor = conn.cursor()
    
    # 🆕 先删除旧表（如果存在）
    cursor.execute('DROP TABLE IF EXISTS submissions')
    cursor.execute('DROP TABLE IF EXISTS users')
    
    # 创建 submissions 表，使用自增阿拉伯数字ID
    cursor.execute('''
        CREATE TABLE submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,  -- 🆕 阿拉伯数字自增ID
            reddit_id TEXT UNIQUE,                 -- 🆕 保留Reddit原始ID
            title TEXT,
            submitter TEXT,
            discussion_url TEXT,
            url TEXT,
            score INTEGER,
            num_comments INTEGER,
            created_date REAL,
            post_content TEXT,
            timezone TEXT,
            location TEXT,
            crawled_time TEXT,
            created_datetime TEXT
        )
    ''')
    
    # 创建用户表
    cursor.execute('''
        CREATE TABLE users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,  -- 🆕 阿拉伯数字自增ID
            username TEXT UNIQUE,
            comment_karma INTEGER,
            link_karma INTEGER,
            user_created REAL,
            user_timezone TEXT
        )
    ''')
    
    conn.commit()
    conn.close()
    print("✅ 数据库重新初始化完成（使用阿拉伯数字ID，无HTML内容）")
    
def save_submissions(submissions):
    """保存提交数据"""
    if not submissions:
        print("❌ 没有提交数据可保存")
        return
        
    conn = sqlite3.connect('reddit_data.db')
    cursor = conn.cursor()
    
    count = 0
    for submission in submissions:
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO submissions 
                (reddit_id, title, submitter, discussion_url, url, score, num_comments, 
                 created_date, post_content, timezone, location, crawled_time, created_datetime)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', submission)
            count += 1
        except Exception as e:
            print(f"❌ 保存提交失败: {e}")
    
    conn.commit()
    conn.close()
    print(f"✅ 已保存 {count}/{len(submissions)} 个提交到数据库")

def save_users(users):
    """保存用户数据"""
    if not users:
        print("❌ 没有用户数据可保存")
        return
        
    conn = sqlite3.connect('reddit_data.db')
    cursor = conn.cursor()
    
    count = 0
    for user in users:
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO users 
                (username, comment_karma, link_karma, user_created, user_timezone)
                VALUES (?, ?, ?, ?, ?)
            ''', user)
            count += 1
        except Exception as e:
            print(f"❌ 保存用户失败: {e}")
    
    conn.commit()
    conn.close()
    print(f"✅ 已保存 {count}/{len(users)} 个用户到数据库")

# 创建带有重试策略的 session
session = requests.Session()
retry_strategy = Retry(
    total=2,
    status_forcelist=[429, 500, 502, 503, 504],
    allowed_methods=["HEAD", "GET", "OPTIONS"],
    backoff_factor=1
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("http://", adapter)
session.mount("https://", adapter)

def request_reddit_data(url, timeout=10):
    """向 Reddit 发送请求并返回 JSON 数据。"""
    delay = random.uniform(2, 3)
    print(f"等待 {delay:.1f} 秒...")
    time.sleep(delay)
    
    headers = {
        "User-agent": "reddit_crawler_final_v1.0",
        "Accept": "application/json"
    }
    
    try:
        print(f"请求: {url}")
        response = session.get(BASE_URL + url, headers=headers, timeout=timeout)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.HTTPError as e:
        if response.status_code == 429:
            print(f"⚠️ 请求过于频繁，等待 20 秒后重试...")
            time.sleep(20)
            return request_reddit_data(url, timeout)
        else:
            print(f"❌ HTTP 错误: {e}")
            return {"data": {}}
    except Exception as e:
        print(f"❌ 请求失败: {e}")
        return {"data": {}}

# def get_subreddit_pages(subreddit, pages):
#     """获取子版块页面数据，不获取评论"""
#     all_submissions = []
    
#     next_page = ""
#     for i in range(pages):
#         print(f"\n📄 正在爬取第 {i+1}/{pages} 页...")
#         next_page = get_submissions_subreddit(
#             f"r/{subreddit}/.json?{next_page}", all_submissions
#         )
#         if not next_page:
#             print("✅ 没有更多页面了")
#             break
    
#     print(f"📊 爬取完成，开始保存数据...")
#     print(f"   提交数: {len(all_submissions)}")
#     print(f"   用户数: {len(usernames)}")
    
#     # 保存数据
#     save_submissions(all_submissions)
    
#     # 获取并保存用户信息
#     users = get_all_users_info()
#     save_users(users)
    
#     print(f"\n🎉 所有数据保存完成！")

def search_company_posts(company_keywords, pages):
    """搜索包含公司关键词的帖子"""
    all_submissions = []
    
    for keyword in company_keywords:
        print(f"\n🔍 搜索关键词: {keyword}")
        next_page = ""
        for i in range(pages):
            print(f"📄 正在爬取第 {i+1}/{pages} 页...")
            next_page = get_submissions_search(
                f"search.json?q={keyword}&type=link&{next_page}", all_submissions
            )
            if not next_page:
                break
            time.sleep(2)  # 避免请求过快
    
    return all_submissions

def get_submissions_search(url_params, all_submissions):
    """获取搜索结果的提交数据"""
    data = request_reddit_data(url_params).get("data", {})
    if not data:
        print("❌ 获取搜索数据失败，跳过此页")
        return ""
        
    submissions = data.get("children", [])
    print(f"📝 本页找到 {len(submissions)} 个相关提交")
    
    for i, s in enumerate(submissions):
        sd = s.get("data", {})
        reddit_id = sd.get("id")
        title = sd.get("title")
        short_title = title[:50] + "..." if title and len(title) > 50 else title
        submitter = sd.get("author")
        discussion_url = sd.get("permalink")
        url = sd.get("url")
        score = sd.get("score")
        num_comments = sd.get("num_comments")
        created_date = sd.get("created")
        
        post_content = sd.get("selftext", "")
        
        timezone = "UTC"
        location = "Unknown"
        crawled_time = datetime.now().isoformat()
        created_datetime = datetime.fromtimestamp(created_date).isoformat() if created_date else ""
        
        print(f"  {i+1}. {short_title} (by {submitter})")
        
        submission = (
            reddit_id,
            title,
            submitter,
            discussion_url,
            url,
            score,
            num_comments,
            created_date,
            post_content,
            timezone,
            location,
            crawled_time,
            created_datetime
        )
        all_submissions.append(submission)
        
        if submitter:
            usernames.add(submitter)
    
    after = data.get("after")
    return f"after={after}" if after else ""

def get_submissions_subreddit(url_params, all_submissions):
    """获取提交数据"""
    data = request_reddit_data(url_params).get("data", {})
    if not data:
        print("❌ 获取数据失败，跳过此页")
        return ""
        
    submissions = data.get("children", [])
    print(f"📝 本页找到 {len(submissions)} 个提交")
    
    for i, s in enumerate(submissions):
        sd = s.get("data", {})
        reddit_id = sd.get("id")  # 🆕 使用 reddit_id 存储原始ID
        title = sd.get("title")
        short_title = title[:50] + "..." if title and len(title) > 50 else title
        submitter = sd.get("author")
        discussion_url = sd.get("permalink")
        url = sd.get("url")
        score = sd.get("score")
        num_comments = sd.get("num_comments")
        created_date = sd.get("created")
        
        # 获取帖子正文内容（删除HTML内容）
        post_content = sd.get("selftext", "")
        
        # 时区和地点信息
        timezone = "UTC"
        location = "Unknown"
        
        # 时间信息
        crawled_time = datetime.now().isoformat()
        created_datetime = datetime.fromtimestamp(created_date).isoformat() if created_date else ""
        
        print(f"  {i+1}. {short_title} (by {submitter})")
        print(f"    📍 地点: {location} | 🕐 时区: {timezone}")
        
        submission = (
            reddit_id,          # 🆕 原始Reddit ID
            title,
            submitter,
            discussion_url,
            url,
            score,
            num_comments,
            created_date,
            post_content,       # ❌ 删除HTML内容
            timezone,
            location,
            crawled_time,
            created_datetime
        )
        all_submissions.append(submission)
        
        if submitter:
            usernames.add(submitter)
    
    after = data.get("after")
    return f"after={after}" if after else ""

def get_all_users_info():
    """获取用户信息"""
    users = []
    username_list = list(usernames)
    
    print(f"🔍 获取 {len(username_list)} 个用户的信息...")
    for i, username in enumerate(username_list):
        if username in ["[deleted]", "[removed]", None]:
            continue
            
        print(f"  用户 {i+1}/{len(username_list)}: {username}")
        user = get_user_info(username)
        if user:
            users.append(user)
        
        time.sleep(1)
    
    return users

def get_user_info(username):
    """获取用户详细信息"""
    url_params = f"user/{username}/about.json"
    try:
        info = request_reddit_data(url_params).get("data", {})
        if info:
            return (
                username,
                info.get("comment_karma", 0),
                info.get("link_karma", 0),
                info.get("created_utc", 0),
                "UTC"
            )
    except Exception as e:
        print(f"❌ 获取用户 {username} 信息失败: {e}")
    return None

if __name__ == "__main__":
    print("🚀 Reddit 爬虫启动（最终版）")
    print("🎯 阿拉伯数字ID | 无HTML内容")
    init_database()
    try:
        pages = int(sys.argv[1])
        pages = min(pages, 3)
        if pages <= 0:
            raise ValueError
        
        print(f"🎯 目标: 爬取 r/Python 的 {pages} 页数据")
        print("⏰ 不获取评论，只获取帖子和用户信息")
        print("🔢 使用阿拉伯数字自增ID")
        print("❌ 不保存HTML内容")
        print("=" * 50)
        
        start_time = time.time()
        # get_subreddit_pages("Python", pages)
        # 新的调用：
        company_keywords = [
            "Google", "Microsoft", "Apple", "Amazon", "Meta", "Facebook",
            "Netflix", "Tesla", "NVIDIA", "Intel", "AMD", "IBM",
            "Python hiring", "software engineer", "tech company",
            "startup", "Silicon Valley", "FAANG"
        ]

        print(f"🎯 目标: 搜索公司相关帖子，关键词: {company_keywords}")
        all_submissions = search_company_posts(company_keywords, pages)

        # 然后继续保存数据
        save_submissions(all_submissions)
        users = get_all_users_info()
        save_users(users)

        end_time = time.time()
        
        print(f"⏱️ 总耗时: {end_time - start_time:.1f} 秒")
        
    except (IndexError, ValueError):
        print("❌ 使用方法: python reddit_crawler_final.py <页数>")
        print("💡 示例: python reddit_crawler_final.py 1")
    except KeyboardInterrupt:
        print("\n⏹️ 用户中断爬取")
    except Exception as e:
        print(f"\n❌ 程序异常: {e}")
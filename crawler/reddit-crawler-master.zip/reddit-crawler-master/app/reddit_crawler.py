# 不带时区地区 带评论
import sys
import time
import random
import requests
import sqlite_db as db
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "https://www.reddit.com/"
usernames = set()

# 创建带有重试策略的 session
session = requests.Session()
retry_strategy = Retry(
    total=2,  # 减少重试次数
    status_forcelist=[429, 500, 502, 503, 504],
    allowed_methods=["HEAD", "GET", "OPTIONS"],
    backoff_factor=1
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("http://", adapter)
session.mount("https://", adapter)

def request_reddit_data(url, timeout=10):
    """向 Reddit 发送请求并返回 JSON 数据。"""
    # 添加随机延迟，避免请求过快
    delay = random.uniform(2, 3)
    print(f"等待 {delay:.1f} 秒...")
    time.sleep(delay)
    
    headers = {
        "User-agent": "reddit_crawler_py3_v1.0 (by /u/your_username)",
        "Accept": "application/json"
    }
    
    try:
        print(f"请求: {url}")
        response = session.get(BASE_URL + url, headers=headers, timeout=timeout)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.HTTPError as e:
        if response.status_code == 429:
            print(f"⚠️ 请求过于频繁，等待 20 秒后重试...")
            time.sleep(20)
            return request_reddit_data(url, timeout)  # 重试一次
        else:
            print(f"❌ HTTP 错误: {e}")
            return {"data": {}}
    except requests.exceptions.Timeout:
        print(f"❌ 请求超时 (>{timeout}秒)")
        return {"data": {}}
    except Exception as e:
        print(f"❌ 请求失败: {e}")
        return {"data": {}}

def get_subreddit_pages(subreddit, pages):
    all_submissions = []
    all_comments = []
    
    next_page = ""
    for i in range(pages):
        print(f"\n📄 正在爬取第 {i+1}/{pages} 页...")
        next_page = get_submissions_subreddit(
            f"r/{subreddit}/.json?{next_page}", all_submissions, all_comments
        )
        if not next_page:
            print("✅ 没有更多页面了")
            break
    
    print(f"📊 爬取完成，开始保存数据...")
    print(f"   提交数: {len(all_submissions)}")
    print(f"   评论数: {len(all_comments)}")
    print(f"   用户数: {len(usernames)}")
    
    # 直接保存提交和评论，跳过用户信息获取（这是卡顿的主要原因）
    if all_submissions:
        db.save_submissions(all_submissions)
        print(f"✅ 已保存 {len(all_submissions)} 个提交")
    
    if all_comments:
        db.save_submissions_comments(all_comments)
        print(f"✅ 已保存 {len(all_comments)} 个评论")
    
    # 可选：快速保存用户信息（不获取详细信息）
    if usernames:
        quick_save_users()
    
    print(f"\n🎉 所有数据保存完成！")

def quick_save_users():
    """快速保存用户信息，不获取详细数据"""
    users = []
    for username in usernames:
        if username and username not in ["[deleted]", "[removed]", "AutoModerator"]:
            users.append((username, 0, 0))  # 默认karma为0
    
    if users:
        db.save_users(users)
        print(f"✅ 已保存 {len(users)} 个用户基本信息")

def get_submissions_subreddit(url_params, all_submissions, all_comments):
    data = request_reddit_data(url_params).get("data", {})
    if not data:
        print("❌ 获取数据失败，跳过此页")
        return ""
        
    submissions = data.get("children", [])
    print(f"📝 本页找到 {len(submissions)} 个提交")
    
    for i, s in enumerate(submissions):
        sd = s.get("data", {})
        submission_id = sd.get("id")
        title = sd.get("title")
        short_title = title[:50] + "..." if title and len(title) > 50 else title
        submitter = sd.get("author")
        discussion_url = sd.get("permalink")
        url = sd.get("url")
        score = sd.get("score")
        num_comments = sd.get("num_comments")
        created_date = sd.get("created")
        
        post_content = sd.get("selftext", "")  # 帖子正文
        content_html = sd.get("selftext_html", "")  # HTML格式的正文
        
        print(f"  {i+1}. {short_title} (by {submitter})")
        
        submission = (
            submission_id,
            title,
            submitter,
            discussion_url,
            url,
            score,
            num_comments,
            created_date,
            post_content,      # 🆕 新增字段
            content_html 
        )
        all_submissions.append(submission)
        
        # 只获取评论数较少的提交的评论，避免过多请求
        if num_comments and num_comments < 30 and num_comments > 0:
            comments = get_submission_comments(submission_id, discussion_url)
            all_comments.extend(comments)
            print(f"    💬 获取了 {len(comments)} 个评论")
        else:
            print(f"    💬 跳过评论（评论数: {num_comments}）")
        
        if submitter:
            usernames.add(submitter)
    
    after = data.get("after")
    return f"after={after}" if after else ""

def get_submission_comments(submission_id, comments_url):
    all_comments = []
    url_params = f"{comments_url}.json"
    data = request_reddit_data(url_params)
    
    if not data or len(data) < 2:
        return all_comments
        
    # 跳过第 0 项（submission 本身）
    comments = data[1]["data"].get("children", [])
    get_comments_data(comments, all_comments, submission_id)
    return all_comments

def get_comments_data(comments, all_comments, submission_id, depth=0):
    """递归获取评论数据，添加深度限制"""
    if depth > 2:  # 限制递归深度
        return
        
    for comment in comments:
        cdata = comment.get("data", {})
        if "author" not in cdata or cdata.get("author") in ["[deleted]", "[removed]"]:
            continue
        
        comment_id = cdata.get("id")
        parent_id = cdata.get("parent_id")
        user = cdata.get("author")
        text = cdata.get("body")
        score = cdata.get("score")
        
        # 限制评论文本长度
        if text and len(text) > 500:
            text = text[:500] + "..."
        
        all_comments.append((comment_id, parent_id, submission_id, user, text, score))
        usernames.add(user)
        
        # 限制递归深度和总评论数
        replies = cdata.get("replies")
        if isinstance(replies, dict) and len(all_comments) < 30:  # 限制总评论数
            children = replies.get("data", {}).get("children", [])
            get_comments_data(children, all_comments, submission_id, depth + 1)

if __name__ == "__main__":
    print("🚀 Reddit 爬虫启动...")
    db.create_schema_db()
    try:
        pages = int(sys.argv[1])
        # 限制最大页数为 2，避免过多请求
        pages = min(pages, 2)
        if pages <= 0:
            raise ValueError
        
        print(f"🎯 目标: 爬取 r/Python 的 {pages} 页数据")
        print("⏰ 保守爬取策略，跳过用户详细信息获取")
        print("📊 只获取评论数少于30的提交")
        print("=" * 50)
        
        start_time = time.time()
        get_subreddit_pages("Python", pages)
        end_time = time.time()
        
        print(f"⏱️ 总耗时: {end_time - start_time:.1f} 秒")
        
    except (IndexError, ValueError):
        print("❌ 使用方法: python reddit_crawler.py <页数>")
        print("💡 建议: python reddit_crawler.py 1")
    except KeyboardInterrupt:
        print("\n⏹️ 用户中断爬取")
    except Exception as e:
        print(f"\n❌ 程序异常: {e}")

# import sys
# import time
# import random
# import requests
# import sqlite_db as db
# from requests.adapters import HTTPAdapter
# from requests.packages.urllib3.util.retry import Retry

# BASE_URL = "https://www.reddit.com/"
# usernames = set()

# # 创建带有重试策略的 session
# session = requests.Session()
# retry_strategy = Retry(
#     total=3,
#     status_forcelist=[429, 500, 502, 503, 504],
#     allowed_methods=["HEAD", "GET", "OPTIONS"],
#     backoff_factor=1
# )
# adapter = HTTPAdapter(max_retries=retry_strategy)
# session.mount("http://", adapter)
# session.mount("https://", adapter)

# def request_reddit_data(url):
#     """向 Reddit 发送请求并返回 JSON 数据。"""
#     # 添加随机延迟，避免请求过快
#     delay = random.uniform(2, 4)
#     print(f"等待 {delay:.1f} 秒...")
#     time.sleep(delay)
    
#     headers = {
#         "User-agent": "reddit_crawler_py3_v1.0 (by /u/your_username)",
#         "Accept": "application/json"
#     }
    
#     try:
#         print(f"请求: {url}")
#         response = session.get(BASE_URL + url, headers=headers, timeout=15)
#         response.raise_for_status()
#         return response.json()
#     except requests.exceptions.HTTPError as e:
#         if response.status_code == 429:
#             print(f"⚠️ 请求过于频繁，等待 30 秒后重试...")
#             time.sleep(30)
#             return request_reddit_data(url)  # 重试一次
#         else:
#             print(f"❌ HTTP 错误: {e}")
#             return {"data": {}}
#     except Exception as e:
#         print(f"❌ 请求失败: {e}")
#         return {"data": {}}

# def get_subreddit_pages(subreddit, pages):
#     all_submissions = []
#     all_comments = []
    
#     next_page = ""
#     for i in range(pages):
#         print(f"\n📄 正在爬取第 {i+1}/{pages} 页...")
#         next_page = get_submissions_subreddit(
#             f"r/{subreddit}/.json?{next_page}", all_submissions, all_comments
#         )
#         if not next_page:
#             print("✅ 没有更多页面了")
#             break
    
#     # 只保存获取到的用户信息
#     if usernames:
#         print(f"👥 获取用户信息，共 {len(usernames)} 个用户...")
#         all_users_info = get_all_users_info()
#         if all_users_info:
#             db.save_users(all_users_info)
#             print(f"✅ 已保存 {len(all_users_info)} 个用户信息")
    
#     if all_submissions:
#         db.save_submissions(all_submissions)
#         print(f"✅ 已保存 {len(all_submissions)} 个提交")
    
#     if all_comments:
#         db.save_submissions_comments(all_comments)
#         print(f"✅ 已保存 {len(all_comments)} 个评论")
    
#     print(f"\n🎉 爬取完成！总计获取了 {len(all_submissions)} 个提交和 {len(all_comments)} 个评论")

# def get_submissions_subreddit(url_params, all_submissions, all_comments):
#     data = request_reddit_data(url_params).get("data", {})
#     if not data:
#         print("❌ 获取数据失败，跳过此页")
#         return ""
        
#     submissions = data.get("children", [])
#     print(f"📝 本页找到 {len(submissions)} 个提交")
    
#     for i, s in enumerate(submissions):
#         sd = s.get("data", {})
#         submission_id = sd.get("id")
#         title = sd.get("title")[:50] + "..." if sd.get("title") and len(sd.get("title")) > 50 else sd.get("title")
#         submitter = sd.get("author")
#         discussion_url = sd.get("permalink")
#         url = sd.get("url")
#         score = sd.get("score")
#         num_comments = sd.get("num_comments")
#         created_date = sd.get("created")
        
#         print(f"  {i+1}. {title} (by {submitter})")
        
#         submission = (
#             submission_id,
#             sd.get("title"),  # 完整标题
#             submitter,
#             discussion_url,
#             url,
#             score,
#             num_comments,
#             created_date,
#         )
#         all_submissions.append(submission)
        
#         # 只获取评论数较少的提交的评论，避免过多请求
#         if num_comments and num_comments < 50:
#             comments = get_submission_comments(submission_id, discussion_url)
#             all_comments.extend(comments)
#             print(f"    💬 获取了 {len(comments)} 个评论")
#         else:
#             print(f"    💬 跳过评论（评论数: {num_comments}）")
        
#         if submitter:
#             usernames.add(submitter)
    
#     after = data.get("after")
#     return f"after={after}" if after else ""

# def get_submission_comments(submission_id, comments_url):
#     all_comments = []
#     url_params = f"{comments_url}.json"
#     data = request_reddit_data(url_params)
    
#     if not data or len(data) < 2:
#         return all_comments
        
#     # 跳过第 0 项（submission 本身）
#     comments = data[1]["data"].get("children", [])
#     get_comments_data(comments, all_comments, submission_id)
#     return all_comments

# def get_comments_data(comments, all_comments, submission_id):
#     for comment in comments:
#         cdata = comment.get("data", {})
#         if "author" not in cdata or cdata.get("author") in ["[deleted]", "[removed]"]:
#             continue
        
#         comment_id = cdata.get("id")
#         parent_id = cdata.get("parent_id")
#         user = cdata.get("author")
#         text = cdata.get("body")
#         score = cdata.get("score")
        
#         # 限制评论文本长度
#         if text and len(text) > 500:
#             text = text[:500] + "..."
        
#         all_comments.append((comment_id, parent_id, submission_id, user, text, score))
#         usernames.add(user)
        
#         # 限制递归深度，避免获取过多回复
#         replies = cdata.get("replies")
#         if isinstance(replies, dict) and len(all_comments) < 50:  # 限制总评论数
#             children = replies.get("data", {}).get("children", [])
#             get_comments_data(children, all_comments, submission_id)

# def get_all_users_info():
#     users = []
#     username_list = list(usernames)
    
#     print(f"🔍 获取 {len(username_list)} 个用户的信息...")
#     for i, username in enumerate(username_list):
#         if username in ["[deleted]", "[removed]", None]:
#             continue
            
#         print(f"  用户 {i+1}/{len(username_list)}: {username}")
#         user = get_user_info(username)
#         if isinstance(user, tuple):
#             users.append(user)
        
#         # 用户信息请求之间也添加延迟
#         time.sleep(1)
    
#     return users

# def get_user_info(username):
#     url_params = f"user/{username}/about.json"
#     try:
#         info = request_reddit_data(url_params).get("data", {})
#         return (username, info.get("comment_karma", 0), info.get("link_karma", 0))
#     except Exception:
#         return None

# def get_user_posts(username):
#     all_user_submissions = []
#     next_page = ""
    
#     while next_page != "null":
#         url_params = f"user/{username}/submitted/.json?after={next_page}"
#         data = request_reddit_data(url_params).get("data", {})
#         submissions = data.get("children", [])
#         all_user_submissions.extend(submissions)
#         next_page = data.get("after") or "null"
    
#     return all_user_submissions

# def get_posts_user_commented(username):
#     all_user_comments = []
#     next_page = ""
    
#     while next_page != "null":
#         url_params = f"user/{username}/comments/.json?after={next_page}"
#         data = request_reddit_data(url_params).get("data", {})
#         comments = data.get("children", [])
#         all_user_comments.extend(comments)
#         next_page = data.get("after") or "null"
    
#     return all_user_comments

# if __name__ == "__main__":
#     print("🚀 Reddit 爬虫启动...")
#     db.create_schema_db()
#     try:
#         pages = int(sys.argv[1])
#         # 限制最大页数为 3，避免过多请求
#         pages = min(pages, 3)
#         if pages <= 0:
#             raise ValueError
        
#         print(f"🎯 目标: 爬取 r/Python 的 {pages} 页数据")
#         print("⏰ 这是一个保守的爬取策略，每个请求之间有 2-4 秒延迟")
#         print("📊 只会获取评论数少于 50 的提交的评论")
#         print("=" * 50)
        
#         get_subreddit_pages("Python", pages)
        
#     except (IndexError, ValueError):
#         print("❌ 使用方法: python reddit_crawler.py <页数>")
#         print("💡 建议: 从 1 页开始测试，例如: python reddit_crawler.py 1")
#     except KeyboardInterrupt:
#         print("\n⏹️ 用户中断爬取")
#     except Exception as e:
#         print(f"\n❌ 程序异常: {e}")

# import sys
# import requests
# import sqlite_db as db

# BASE_URL = "https://www.reddit.com/"
# usernames = set()

# def request_reddit_data(url):
#     """向 Reddit 发送请求并返回 JSON 数据。"""
#     response = requests.get(BASE_URL + url, headers={"User-agent": "reddit_crawler_py3"})
#     response.raise_for_status()
#     return response.json()

# def get_subreddit_pages(subreddit, pages):
#     all_submissions = []
#     all_comments = []
    
#     next_page = ""
#     for _ in range(pages):
#         next_page = get_submissions_subreddit(
#             f"r/{subreddit}/.json?{next_page}", all_submissions, all_comments
#         )
    
#     all_users_info = get_all_users_info()
#     db.save_users(all_users_info)
#     db.save_submissions(all_submissions)
#     db.save_submissions_comments(all_comments)

# def get_submissions_subreddit(url_params, all_submissions, all_comments):
#     data = request_reddit_data(url_params).get("data", {})
#     submissions = data.get("children", [])
    
#     for s in submissions:
#         sd = s.get("data", {})
#         submission_id = sd.get("id")
#         title = sd.get("title")
#         submitter = sd.get("author")
#         discussion_url = sd.get("permalink")
#         url = sd.get("url")
#         score = sd.get("score")
#         num_comments = sd.get("num_comments")
#         created_date = sd.get("created")
        
#         submission = (
#             submission_id,
#             title,
#             submitter,
#             discussion_url,
#             url,
#             score,
#             num_comments,
#             created_date,
#         )
#         all_submissions.append(submission)
        
#         all_comments += get_submission_comments(submission_id, discussion_url)
#         if submitter:
#             usernames.add(submitter)
    
#     after = data.get("after")
#     return f"after={after}" if after else ""

# def get_submission_comments(submission_id, comments_url):
#     all_comments = []
#     url_params = f"{comments_url}.json"
#     data = request_reddit_data(url_params)
    
#     # 跳过第 0 项（submission 本身）
#     comments = data[1]["data"].get("children", [])
#     get_comments_data(comments, all_comments, submission_id)
#     return all_comments

# def get_comments_data(comments, all_comments, submission_id):
#     for comment in comments:
#         cdata = comment.get("data", {})
#         if "author" not in cdata:
#             continue
        
#         comment_id = cdata.get("id")
#         parent_id = cdata.get("parent_id")
#         user = cdata.get("author")
#         text = cdata.get("body")
#         score = cdata.get("score")
        
#         all_comments.append((comment_id, parent_id, submission_id, user, text, score))
#         usernames.add(user)
        
#         replies = cdata.get("replies")
#         if isinstance(replies, dict):
#             children = replies.get("data", {}).get("children", [])
#             get_comments_data(children, all_comments, submission_id)

# def get_all_users_info():
#     users = []
#     for username in usernames:
#         user = get_user_info(username)
#         if isinstance(user, tuple):
#             users.append(user)
#     return users

# def get_user_info(username):
#     url_params = f"user/{username}/about.json"
#     try:
#         info = request_reddit_data(url_params).get("data", {})
#         return (username, info.get("comment_karma", 0), info.get("link_karma", 0))
#     except Exception:
#         return None

# def get_user_posts(username):
#     all_user_submissions = []
#     next_page = ""
    
#     while next_page != "null":
#         url_params = f"user/{username}/submitted/.json?after={next_page}"
#         data = request_reddit_data(url_params).get("data", {})
#         submissions = data.get("children", [])
#         all_user_submissions.extend(submissions)
#         next_page = data.get("after") or "null"
    
#     return all_user_submissions

# def get_posts_user_commented(username):
#     all_user_comments = []
#     next_page = ""
    
#     while next_page != "null":
#         url_params = f"user/{username}/comments/.json?after={next_page}"
#         data = request_reddit_data(url_params).get("data", {})
#         comments = data.get("children", [])
#         all_user_comments.extend(comments)
#         next_page = data.get("after") or "null"
    
#     return all_user_comments

# if __name__ == "__main__":
#     db.create_schema_db()
#     try:
#         pages = int(sys.argv[1])
#         if pages <= 0:
#             raise ValueError
#         get_subreddit_pages("Python", pages)
#     except (IndexError, ValueError):
#         print("A valid number of pages needs to be passed as parameter")
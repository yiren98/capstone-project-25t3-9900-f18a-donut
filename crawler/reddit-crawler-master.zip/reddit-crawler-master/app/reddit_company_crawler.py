import sys
import time
import random
import requests
import sqlite3
from datetime import datetime
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "https://www.reddit.com/"
usernames = set()

# 公司关键词列表
COMPANY_KEYWORDS = [
    "Google", "Microsoft", "Apple", "Amazon", "Meta", "Facebook",
    "Netflix", "Tesla", "NVIDIA", "Intel", "AMD", "IBM",
    "Python hiring", "software engineer", "tech company",
    "startup", "Silicon Valley", "FAANG", "tech interview",
    "programming job", "developer salary", "coding interview"
]

# 保持原有的 init_database(), save_submissions(), save_users() 函数不变
# 保持原有的 session 和 request_reddit_data() 函数不变

def search_company_posts(pages):
    """搜索包含公司关键词的帖子"""
    all_submissions = []
    
    for keyword in COMPANY_KEYWORDS:
        print(f"\n🔍 搜索关键词: '{keyword}'")
        next_page = ""
        for i in range(pages):
            print(f"📄 正在爬取第 {i+1}/{pages} 页...")
            next_page = get_submissions_search(
                f"search.json?q={keyword}&type=link&sort=relevance&{next_page}", 
                all_submissions,
                keyword
            )
            if not next_page:
                print(f"✅ 关键词 '{keyword}' 没有更多结果")
                break
            time.sleep(2)  # 避免请求过快
    
    print(f"📊 搜索完成，共找到 {len(all_submissions)} 个相关帖子")
    print(f"   用户数: {len(usernames)}")
    
    return all_submissions

def get_all_users_info_batch():
    """分批获取用户信息，避免过多请求"""
    users = []
    username_list = list(usernames)
    
    print(f"🔍 分批获取 {len(username_list)} 个用户的信息...")
    
    # 分批处理，每批50个用户
    batch_size = 50
    for batch_num in range(0, len(username_list), batch_size):
        batch = username_list[batch_num:batch_num + batch_size]
        print(f"\n📦 处理批次 {batch_num//batch_size + 1}/{(len(username_list)-1)//batch_size + 1}")
        
        for i, username in enumerate(batch):
            if username in ["[deleted]", "[removed]", None]:
                continue
                
            print(f"  用户 {batch_num + i + 1}/{len(username_list)}: {username}")
            user = get_user_info_with_retry(username)
            if user:
                users.append(user)
            
            # 批次内延迟
            delay = random.uniform(3, 5)
            time.sleep(delay)
        
        # 🆕 批次间长时间休息
        if batch_num + batch_size < len(username_list):
            long_break = random.uniform(60, 120)  # 1-2分钟休息
            print(f"🛌 批次完成，休息 {long_break:.1f} 秒...")
            time.sleep(long_break)
    
    return users

def get_submissions_search(url_params, all_submissions, keyword):
    """获取搜索结果的提交数据"""
    data = request_reddit_data(url_params).get("data", {})
    if not data:
        print("❌ 获取搜索数据失败，跳过此页")
        return ""
        
    submissions = data.get("children", [])
    print(f"📝 本页找到 {len(submissions)} 个相关提交")
    
    for i, s in enumerate(submissions):
        sd = s.get("data", {})
        reddit_id = sd.get("id")
        title = sd.get("title")
        short_title = title[:50] + "..." if title and len(title) > 50 else title
        submitter = sd.get("author")
        discussion_url = sd.get("permalink")
        url = sd.get("url")
        score = sd.get("score")
        num_comments = sd.get("num_comments")
        created_date = sd.get("created")
        
        post_content = sd.get("selftext", "")
        
        timezone = "UTC"
        location = "Unknown"
        crawled_time = datetime.now().isoformat()
        created_datetime = datetime.fromtimestamp(created_date).isoformat() if created_date else ""
        
        print(f"  {i+1}. {short_title} (by {submitter})")
        print(f"    🔍 匹配关键词: {keyword}")
        
        submission = (
            reddit_id,
            title,
            submitter,
            discussion_url,
            url,
            score,
            num_comments,
            created_date,
            post_content,
            timezone,
            location,
            crawled_time,
            created_datetime
        )
        all_submissions.append(submission)
        
        if submitter:
            usernames.add(submitter)
    
    after = data.get("after")
    return f"after={after}" if after else ""

if __name__ == "__main__":
    print("🚀 Reddit 公司相关帖子爬虫启动")
    print("🎯 目标: 搜索科技公司、招聘、面试相关帖子")
    init_database()
    
    try:
        pages = int(sys.argv[1]) if len(sys.argv) > 1 else 1
        pages = min(pages, 2)  # 限制页数避免过多请求
        
        print(f"🎯 每个关键词爬取 {pages} 页数据")
        print(f"🔍 搜索关键词: {COMPANY_KEYWORDS}")
        print("=" * 50)
        
        start_time = time.time()
        
        # 🆕 使用新的搜索函数
        all_submissions = search_company_posts(pages)
        
        # 保存数据
        save_submissions(all_submissions)
        users = get_all_users_info()
        save_users(users)
        
        end_time = time.time()
        print(f"⏱️ 总耗时: {end_time - start_time:.1f} 秒")
        
    except KeyboardInterrupt:
        print("\n⏹️ 用户中断爬取")
    except Exception as e:
        print(f"\n❌ 程序异常: {e}")
import fixed_sqlite_db as db

# 测试数据
test_submissions = [
    ("test_id_1", "Test Title 1", "test_user", "/r/test", "http://example.com", 100, 10, 1234567890),
    ("test_id_2", "Test Title 2", "test_user2", "/r/test2", "http://example.com", 200, 20, 1234567890)
]

test_comments = [
    ("comment_1", "t3_test_id_1", "test_id_1", "user1", "This is a test comment", 5),
    ("comment_2", "t1_comment_1", "test_id_1", "user2", "This is a reply", 3)
]

test_users = [
    ("user1", 1000, 500),
    ("user2", 2000, 300)
]

# 测试数据库操作
db.create_schema_db()
db.save_submissions(test_submissions)
db.save_submissions_comments(test_comments)
db.save_users(test_users)

print("🧪 测试数据已保存，请检查数据库...")
# cleanup.py
import os

if os.path.exists('reddit_data.db'):
    os.remove('reddit_data.db')
    print("🗑️ 已删除旧数据库文件")

if os.path.exists('submissions.csv'):
    os.remove('submissions.csv')
    print("🗑️ 已删除旧CSV文件")

if os.path.exists('users.csv'):
    os.remove('users.csv') 
    print("🗑️ 已删除旧用户CSV文件")

print("✅ 清理完成，现在可以重新运行爬虫了")
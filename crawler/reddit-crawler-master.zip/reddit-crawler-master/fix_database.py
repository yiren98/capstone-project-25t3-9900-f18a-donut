import sqlite3
import os

def create_database_schema():
    # 连接到数据库
    conn = sqlite3.connect('reddit_data.db')
    cursor = conn.cursor()
    
    # 创建表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS submissions (
            id TEXT PRIMARY KEY,
            title TEXT,
            submitter TEXT,
            discussion_url TEXT,
            url TEXT,
            score INTEGER,
            num_comments INTEGER,
            created_date REAL
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS comments (
            comment_id TEXT PRIMARY KEY,
            parent_id TEXT,
            submission_id TEXT,
            user TEXT,
            text TEXT,
            score INTEGER,
            FOREIGN KEY (submission_id) REFERENCES submissions (id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            comment_karma INTEGER,
            link_karma INTEGER
        )
    ''')
    
    # 提交更改
    conn.commit()
    
    # 验证表是否创建成功
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    print("创建的表:")
    for table in tables:
        print(f"  - {table[0]}")
    
    conn.close()
    print("✅ 数据库架构创建完成！")

if __name__ == "__main__":
    create_database_schema()